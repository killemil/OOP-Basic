﻿namespace _08MordorCrueltyPlan.Models.Foods
{
    public class Junk : Food
    {
        private const int HapinessPoints = -1;
        public Junk() 
            : base(HapinessPoints)
        {
        }
    }
}
