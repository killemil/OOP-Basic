﻿namespace _08MordorCrueltyPlan.Models.Foods
{
    public class Melon : Food
    {
        private const int HapinessPoints = 1;
        public Melon() 
            : base(HapinessPoints)
        {
        }
    }
}
