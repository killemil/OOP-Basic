﻿namespace _08MordorCrueltyPlan.Models.Foods
{
    public class Apple : Food
    {
        private const int HapinessPoints = 1;
        public Apple() 
            : base(HapinessPoints)
        {
        }
    }
}
