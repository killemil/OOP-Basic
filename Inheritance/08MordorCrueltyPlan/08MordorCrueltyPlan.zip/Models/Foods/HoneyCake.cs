﻿namespace _08MordorCrueltyPlan.Models.Foods
{
    public class HoneyCake : Food
    {
        private const int HapinessPoints = 5;
        public HoneyCake() 
            : base(HapinessPoints)
        {
        }
    }
}
