﻿namespace _08MordorCrueltyPlan.Models.Moods
{
    public class JavaScript : Mood
    {
        private const string MoodName = "JavaScript";
        public JavaScript() : base(MoodName)
        {
        }
    }
}
