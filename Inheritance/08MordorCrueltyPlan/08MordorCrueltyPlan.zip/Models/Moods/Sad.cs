﻿namespace _08MordorCrueltyPlan.Models.Moods
{
    public class Sad : Mood
    {
        private const string MoodName = "Sad";
        public Sad() : base(MoodName)
        {
        }
    }
}
