﻿namespace _08MordorCrueltyPlan.Models.Moods
{
public     class Happy : Mood
    {
        private const string MoodName = "Happy";
        public Happy() : base(MoodName)
        {
        }
    }
}
