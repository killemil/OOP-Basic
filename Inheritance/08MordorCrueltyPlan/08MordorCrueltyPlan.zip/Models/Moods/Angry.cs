﻿
namespace _08MordorCrueltyPlan.Models.Moods
{
    public class Angry : Mood
    {
        private const string MoodName = "Angry";
        public Angry() : base(MoodName)
        {
        }
    }
}
