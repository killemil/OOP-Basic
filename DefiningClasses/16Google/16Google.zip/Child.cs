﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class Child
{
    private string name;
    private string birthDay;

    public string Name { get { return this.name; } set { this.name = value; } }
    public string BirthDay { get { return this.birthDay; } set { this.birthDay = value; } }
}
