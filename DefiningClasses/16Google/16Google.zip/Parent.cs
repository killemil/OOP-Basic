﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class Parent
{
    private string name;
    private string birthDate;

    public string Name { get { return this.name; } set { this.name = value; } }

    public string BirthDate { get { return this.birthDate; } set { this.birthDate = value; } }
}
