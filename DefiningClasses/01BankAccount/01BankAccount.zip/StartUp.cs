﻿public class StartUp
{
    public static void Main(string[] args)
    {
        BankAccount acc = new BankAccount
        {
            ID = 4,
            Balance = 0.54
        };
    }
}
