﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19DrawingTool
{
    public class Square
    {
        private int size;

        public Square(int size)
        {
            this.size = size;
        }

        public void Draw()
        {

            Console.WriteLine("|" + new string('-', this.size) + "|");
            for (int i = 0; i < this.size - 2; i++)
            {
                Console.WriteLine("|" + new string(' ', this.size) + "|");
            }
            Console.WriteLine("|" + new string('-', this.size) + "|");
        }
    }
}
