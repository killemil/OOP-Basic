﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19DrawingTool
{
    public class CorDraw
    {
        private Square square;
        private Rectangle rectangle;

        public CorDraw(Square square)
        {
            this.square = square;
        }
        public CorDraw(Rectangle rectangle)
        {
            this.rectangle = rectangle;
        }
    }
}
