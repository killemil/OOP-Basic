﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19DrawingTool
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string input = Console.ReadLine();

            if (input.Equals("Square"))
            {
                Square square = new Square(int.Parse(Console.ReadLine()));
                square.Draw();
            }
            else if (input.Equals("Rectangle"))
            {
                int width = int.Parse(Console.ReadLine());
                int height = int.Parse(Console.ReadLine());
                Rectangle rec = new Rectangle(width, height);
                rec.Draw();
            }
        }
    }
}
